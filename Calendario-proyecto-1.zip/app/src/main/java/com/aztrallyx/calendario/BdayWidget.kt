package com.aztrallyx.calendario

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject

/** Widget "Cumpleaños": próximos cumpleaños con cuenta regresiva. */
class BdayWidget : BaseWidget() {

    override fun draw(c: Context, cv: Canvas, w: Int, h: Int, s: Float, t: Theme, data: JSONObject) {
        val pad = 14f * s
        val head = sp(t, s, true, 15f, t.tint)
        cv.drawText("Cumpleaños", pad, pad + head.textSize * 0.85f, head)
        var y = pad + head.textSize * 1.4f

        val arr = data.optJSONArray("bd") ?: JSONArray()
        val today = startOfDay()
        val nameP = sp(t, s, false, 14f, t.fg)
        val subP = sp(t, s, false, 11f, t.sub)
        val emoP = sp(t, s, false, 20f, t.fg)
        val cntP = sp(t, s, true, 13f, t.sub, Paint.Align.RIGHT)
        val rowH = 38f * s * t.fs

        var shown = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val k = Math.round((o.getLong("d") - today) / 86400000.0).toInt()
            if (k < 0) continue
            if (y + rowH > h - pad * 0.5f) break

            cv.drawText(o.optString("i"), pad, y + rowH * 0.66f, emoP)
            val tx = pad + 32f * s * t.fs
            val cnt = when (k) {
                0 -> "Hoy 🎉"
                1 -> "Mañana"
                else -> "$k días"
            }
            cntP.color = if (k <= 7) t.tint else t.sub
            cv.drawText(cnt, w - pad, y + rowH * 0.58f, cntP)

            val avail = w - pad - tx - cntP.measureText(cnt) - 8f * s
            cv.drawText(fit(nameP, o.getString("n"), avail), tx, y + rowH * 0.50f, nameP)
            val age = o.optInt("age", 0)
            val sub = o.optString("dt") + if (age > 0) " · cumple $age" else ""
            cv.drawText(fit(subP, sub, avail), tx, y + rowH * 0.50f + subP.textSize * 1.25f, subP)
            y += rowH
            shown++
        }

        if (shown == 0) {
            cv.drawText("Aún no hay cumpleaños", pad, y + nameP.textSize * 1.4f, nameP)
        }
    }
}
