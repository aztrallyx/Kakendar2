package com.aztrallyx.calendario

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SnoozeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        val sid = id or 0x40000000
        Alarms.set(
            c, sid,
            i.getStringExtra("t") ?: "",
            i.getStringExtra("b") ?: "",
            System.currentTimeMillis() + i.getLongExtra("ms", 600000L)
        )
        c.getSystemService(NotificationManager::class.java).cancel(id)
    }
}
