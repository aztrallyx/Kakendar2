package com.aztrallyx.calendario

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

/** Widget "Próximos": lista de eventos agrupados por día. */
class CalWidget : BaseWidget() {

    override fun draw(c: Context, cv: Canvas, w: Int, h: Int, s: Float, t: Theme, data: JSONObject) {
        val pad = 14f * s
        val head = sp(t, s, true, 15f, t.tint)
        val title = cap(SimpleDateFormat("EEEE d 'de' MMMM", loc()).format(Date()))
        cv.drawText(fit(head, title, w - 2 * pad), pad, pad + head.textSize * 0.85f, head)
        var y = pad + head.textSize * 1.35f

        val items = data.optJSONArray("items") ?: JSONArray()
        val today = startOfDay()
        val now = Calendar.getInstance()
        val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val maxN = data.optJSONObject("cfg")?.optInt("n", 0) ?: 0

        val dayP = sp(t, s, true, 11f, t.sub)
        val timeP = sp(t, s, false, 12f, t.sub, Paint.Align.RIGHT)
        val titleP = sp(t, s, false, 13.5f, t.fg)
        val barP = Paint(Paint.ANTI_ALIAS_FLAG)
        val rowH = 24f * s * t.fs
        val dayH = 20f * s * t.fs

        var last = -1L
        var shown = 0
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i)
            val d = o.getLong("d")
            if (d < today) continue
            if (maxN > 0 && shown >= maxN) break
            val need = (if (d != last) dayH else 0f) + rowH
            if (y + need > h - pad * 0.6f) break

            if (d != last) {
                val k = Math.round((d - today) / 86400000.0).toInt()
                val lbl = when (k) {
                    0 -> "Hoy"
                    1 -> "Mañana"
                    else -> cap(SimpleDateFormat("EEE d MMM", loc()).format(Date(d)))
                }
                cv.drawText(lbl, pad, y + dayP.textSize, dayP)
                y += dayH
                last = d
            }

            val mm = o.optInt("m", -1)
            val past = d == today && mm in 0 until nowMin
            val a = if (past) 110 else 255

            barP.color = try {
                Color.parseColor(o.optString("c"))
            } catch (e: Exception) {
                t.tint
            }
            barP.alpha = a
            cv.drawRoundRect(RectF(pad, y + rowH * 0.12f, pad + 3.5f * s, y + rowH * 0.88f), 2f * s, 2f * s, barP)

            val tm = o.optString("t")
            var right = w - pad
            if (tm.isNotEmpty()) {
                timeP.alpha = a
                cv.drawText(tm, right, y + rowH * 0.68f, timeP)
                right -= timeP.measureText(tm) + 8f * s
            }
            titleP.alpha = a
            val tx = pad + 10f * s
            cv.drawText(fit(titleP, o.optString("i") + " " + o.getString("n"), right - tx), tx, y + rowH * 0.68f, titleP)
            y += rowH
            shown++
        }

        if (shown == 0) {
            cv.drawText("Sin eventos próximos", pad, y + titleP.textSize * 1.4f, titleP)
        }
    }
}
