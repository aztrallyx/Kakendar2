package com.aztrallyx.calendario

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.Locale

class Theme(
    val bg: Int,
    val fg: Int,
    val sub: Int,
    val tint: Int,
    val clear: Boolean,
    val fs: Float,
    val tfTitle: Typeface,
    val tfBody: Typeface,
    val custom: Boolean
)

abstract class BaseWidget : AppWidgetProvider() {

    abstract fun draw(c: Context, cv: Canvas, w: Int, h: Int, s: Float, t: Theme, data: JSONObject)

    open fun extra(c: Context, rv: RemoteViews) {
        rv.setViewVisibility(R.id.w_prev, View.GONE)
        rv.setViewVisibility(R.id.w_next, View.GONE)
    }

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(c, m, id)
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        update(c, m, id)
    }

    private fun update(c: Context, m: AppWidgetManager, id: Int) {
        val o = m.getAppWidgetOptions(id)
        val port = c.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val wDp = o.getInt(
            if (port) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 250
        ).coerceAtLeast(110)
        val hDp = o.getInt(
            if (port) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110
        ).coerceAtLeast(80)

        var s = c.resources.displayMetrics.density
        while (wDp * s * hDp * s > 1_100_000f) s *= 0.85f
        val w = (wDp * s).toInt()
        val h = (hDp * s).toInt()

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val data = try {
            JSONObject(c.getSharedPreferences("w", Context.MODE_PRIVATE).getString("cfg", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val t = theme(c, data.optJSONObject("cfg") ?: JSONObject())

        val bgp = Paint(Paint.ANTI_ALIAS_FLAG)
        bgp.color = t.bg
        cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 22f * s, 22f * s, bgp)
        try {
            draw(c, cv, w, h, s, t, data)
        } catch (e: Exception) {
        }

        val rv = RemoteViews(c.packageName, R.layout.widget_bmp)
        rv.setImageViewBitmap(R.id.w_img, bmp)
        rv.setOnClickPendingIntent(
            R.id.w_root,
            PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        )
        extra(c, rv)
        m.updateAppWidget(id, rv)
    }

    private fun face(c: Context, kind: String): Typeface? {
        val f = File(c.filesDir, "font_$kind")
        if (!f.exists()) return null
        return try {
            Typeface.createFromFile(f)
        } catch (e: Exception) {
            null
        }
    }

    private fun theme(c: Context, cfg: JSONObject): Theme {
        val mode = cfg.optString("bg", "auto")
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val dark = mode == "dark" || mode == "amoled" || mode == "clear" || (mode == "auto" && night)
        val base = if (mode == "amoled") 0x000000 else if (dark) 0x1C1C1E else 0xFFFFFF
        val alpha = if (mode == "clear") 0 else cfg.optInt("alpha", 100).coerceIn(0, 100) * 255 / 100
        val tint = try {
            Color.parseColor(cfg.optString("tint", "#ff3b30"))
        } catch (e: Exception) {
            Color.parseColor("#ff3b30")
        }
        val body = face(c, "body")
        val title = face(c, "title")
        return Theme(
            bg = (alpha shl 24) or base,
            fg = if (dark) Color.WHITE else Color.BLACK,
            sub = if (dark) 0xFF98989F.toInt() else 0xFF6C6C70.toInt(),
            tint = tint,
            clear = mode == "clear",
            fs = cfg.optDouble("fs", 1.0).toFloat().coerceIn(0.7f, 1.6f),
            tfTitle = title ?: body ?: Typeface.DEFAULT,
            tfBody = body ?: Typeface.DEFAULT,
            custom = body != null || title != null
        )
    }

    companion object {
        fun refreshAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val classes = arrayOf<Class<out BaseWidget>>(
                CalWidget::class.java, MonthWidget::class.java, BdayWidget::class.java
            )
            for (cls in classes) {
                val ids = m.getAppWidgetIds(ComponentName(c, cls))
                if (ids.isNotEmpty()) cls.getDeclaredConstructor().newInstance().onUpdate(c, m, ids)
            }
        }

        fun cap(s: String): String = s.replaceFirstChar { it.uppercase() }

        fun loc(): Locale = Locale("es", "MX")

        fun startOfDay(): Long {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            return cal.timeInMillis
        }

        fun px(t: Theme, s: Float, title: Boolean, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT): Paint {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.typeface = if (title) t.tfTitle else t.tfBody
            p.textSize = size
            p.color = color
            p.textAlign = align
            if (title && !t.custom) p.isFakeBoldText = true
            if (t.clear) p.setShadowLayer(3f * s, 0f, 1f * s, 0x99000000.toInt())
            return p
        }

        fun sp(t: Theme, s: Float, title: Boolean, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT): Paint =
            px(t, s, title, size * s * t.fs, color, align)

        fun fit(p: Paint, text: String, maxW: Float): String {
            if (maxW <= 0f) return ""
            if (p.measureText(text) <= maxW) return text
            val n = p.breakText(text, true, maxW - p.measureText("…"), null)
            return text.substring(0, maxOf(0, n)) + "…"
        }
    }
}
