package com.aztrallyx.calendario

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Alarms.restore(c)
        BaseWidget.refreshAll(c)
    }
}
