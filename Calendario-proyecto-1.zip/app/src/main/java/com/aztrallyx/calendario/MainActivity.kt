package com.aztrallyx.calendario

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.view.WindowInsetsController
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    inner class Bridge {
        @JavascriptInterface
        fun schedule(id: Int, title: String, body: String, at: Long) {
            Alarms.set(this@MainActivity, id, title, body, at)
        }

        @JavascriptInterface
        fun cancel(id: Int) {
            Alarms.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun widget(json: String) {
            getSharedPreferences("w", Context.MODE_PRIVATE).edit().putString("cfg", json).apply()
            BaseWidget.refreshAll(this@MainActivity)
        }

        @JavascriptInterface
        fun saveFont(kind: String, b64: String) {
            if (kind != "title" && kind != "body") return
            val f = File(filesDir, "font_$kind")
            if (b64.isEmpty()) f.delete() else f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun theme(bg: String, dark: Boolean) {
            runOnUiThread {
                try {
                    val col = Color.parseColor(bg)
                    window.statusBarColor = col
                    window.navigationBarColor = col
                    web.setBackgroundColor(col)
                    if (Build.VERSION.SDK_INT >= 30) {
                        val ap = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                        window.insetsController?.setSystemBarsAppearance(if (dark) 0 else ap, ap)
                    } else {
                        window.decorView.systemUiVisibility =
                            if (dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                    }
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setIcon(name: String) {
            val all = listOf("rojo", "azul", "verde", "naranja", "morado", "negro")
            if (name !in all) return
            for (n in all) {
                val cn = ComponentName(
                    this@MainActivity,
                    "com.aztrallyx.calendario.Icon" + n.replaceFirstChar { it.uppercase() }
                )
                packageManager.setComponentEnabledSetting(
                    cn,
                    if (n == name) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                    else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        }

        @JavascriptInterface
        fun pinShortcut(b64: String, label: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    val sm = getSystemService(ShortcutManager::class.java)
                    if (sm != null && sm.isRequestPinShortcutSupported) {
                        val info = ShortcutInfo.Builder(this@MainActivity, "custom" + System.currentTimeMillis())
                            .setShortLabel(if (label.isEmpty()) "Calendario" else label)
                            .setIcon(Icon.createWithBitmap(bmp))
                            .setIntent(
                                Intent(this@MainActivity, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
                            )
                            .build()
                        sm.requestPinShortcut(info, null)
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = if (p.acceptTypes.any { it.startsWith("image") }) "image/*" else "*/*"
                }
                startActivityForResult(i, 1)
                return true
            }
        }

        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            val uri = data?.data
            fileCb?.onReceiveValue(if (resultCode == RESULT_OK && uri != null) arrayOf(uri) else null)
            fileCb = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack?window.onBack():false)") {
            if (it != "true") finish()
        }
    }
}
