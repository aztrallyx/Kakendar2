package com.aztrallyx.calendario

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.widget.RemoteViews
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Widget "Mes": cuadrícula del mes con puntos de color y flechas para navegar. */
class MonthWidget : BaseWidget() {

    private fun act(c: Context, a: String, rc: Int): PendingIntent =
        PendingIntent.getBroadcast(
            c, rc,
            Intent(c, MonthWidget::class.java).setAction("com.aztrallyx.calendario.$a"),
            PendingIntent.FLAG_IMMUTABLE
        )

    override fun extra(c: Context, rv: RemoteViews) {
        rv.setViewVisibility(R.id.w_prev, View.VISIBLE)
        rv.setViewVisibility(R.id.w_next, View.VISIBLE)
        rv.setOnClickPendingIntent(R.id.w_prev, act(c, "PREV", 1))
        rv.setOnClickPendingIntent(R.id.w_next, act(c, "NEXT", 2))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val a = i.action ?: return
        if (a.endsWith(".PREV") || a.endsWith(".NEXT")) {
            val p = c.getSharedPreferences("w", Context.MODE_PRIVATE)
            val o = (p.getInt("m_off", 0) + if (a.endsWith(".NEXT")) 1 else -1).coerceIn(-1, 3)
            p.edit().putInt("m_off", o).apply()
            BaseWidget.refreshAll(c)
        }
    }

    override fun draw(c: Context, cv: Canvas, w: Int, h: Int, s: Float, t: Theme, data: JSONObject) {
        val off = c.getSharedPreferences("w", Context.MODE_PRIVATE).getInt("m_off", 0)
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MONTH, off)

        val y0 = cal.get(Calendar.YEAR)
        val m0 = cal.get(Calendar.MONTH)
        val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val first = cal.get(Calendar.DAY_OF_WEEK) - 1
        val tod = Calendar.getInstance()
        val isTodayMonth = tod.get(Calendar.YEAR) == y0 && tod.get(Calendar.MONTH) == m0

        val pad = 12f * s
        val head = sp(t, s, true, 16f, t.fg)
        val hc = 22f * s
        val title = cap(SimpleDateFormat("MMMM yyyy", loc()).format(cal.time))
        cv.drawText(fit(head, title, w - 120f * s), pad, hc + head.textSize * 0.35f, head)
        val arrow = sp(t, s, true, 24f, t.tint, Paint.Align.CENTER)
        cv.drawText("‹", w - 72f * s, hc + arrow.textSize * 0.33f, arrow)
        cv.drawText("›", w - 24f * s, hc + arrow.textSize * 0.33f, arrow)

        val map = HashMap<String, List<Int>>()
        val arr = data.optJSONArray("dots") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val ca = o.getJSONArray("c")
            val l = ArrayList<Int>()
            for (j in 0 until ca.length()) {
                l.add(
                    try {
                        Color.parseColor(ca.getString(j))
                    } catch (e: Exception) {
                        t.tint
                    }
                )
            }
            map[o.getString("k")] = l
        }

        val rows = (first + dim + 6) / 7
        val top = 44f * s
        val wkP = sp(t, s, false, 10.5f, t.sub, Paint.Align.CENTER)
        val cw = (w - 2 * pad) / 7f
        val letters = arrayOf("D", "L", "M", "M", "J", "V", "S")
        for (k in 0..6) cv.drawText(letters[k], pad + cw * (k + 0.5f), top + wkP.textSize, wkP)

        val gTop = top + wkP.textSize * 1.6f
        val ch = (h - gTop - pad * 0.5f) / rows
        val r = minOf(cw, ch * 0.7f) * 0.42f
        val numP = px(t, s, false, r * 1.05f, t.fg, Paint.Align.CENTER)
        val numToday = px(t, s, true, r * 1.05f, Color.WHITE, Paint.Align.CENTER)
        val circ = Paint(Paint.ANTI_ALIAS_FLAG)
        circ.color = t.tint
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)

        for (d in 1..dim) {
            val idx = first + d - 1
            val col = idx % 7
            val row = idx / 7
            val cx = pad + cw * (col + 0.5f)
            val cy = gTop + ch * row + ch * 0.42f
            val isT = isTodayMonth && d == tod.get(Calendar.DAY_OF_MONTH)
            if (isT) cv.drawCircle(cx, cy, r, circ)
            val p = if (isT) numToday else numP
            cv.drawText(d.toString(), cx, cy + p.textSize * 0.35f, p)

            val cols = map[String.format(Locale.US, "%04d-%02d-%02d", y0, m0 + 1, d)]
            if (cols != null && ch > 26f * s) {
                val dr = maxOf(1.6f * s, r * 0.13f)
                val n = cols.size
                val startX = cx - (n - 1) * dr * 1.4f
                for (j in 0 until n) {
                    dot.color = cols[j]
                    cv.drawCircle(startX + j * dr * 2.8f, cy + r + dr * 1.6f, dr, dot)
                }
            }
        }
    }
}
