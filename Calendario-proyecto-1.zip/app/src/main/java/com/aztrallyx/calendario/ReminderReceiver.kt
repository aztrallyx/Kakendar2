package com.aztrallyx.calendario

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        val title = i.getStringExtra("t") ?: ""
        val body = i.getStringExtra("b") ?: ""
        Alarms.forget(c, id)

        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("rem", "Recordatorios", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        fun snooze(label: String, ms: Long, k: Int): Notification.Action {
            val si = Intent(c, SnoozeReceiver::class.java)
                .putExtra("id", id).putExtra("t", title).putExtra("b", body).putExtra("ms", ms)
            val pi = PendingIntent.getBroadcast(
                c, id * 4 + k, si, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(
                Icon.createWithResource(c, android.R.drawable.ic_menu_recent_history), label, pi
            ).build()
        }

        val n = Notification.Builder(c, "rem")
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(snooze("10 min", 10L * 60_000L, 1))
            .addAction(snooze("1 hora", 60L * 60_000L, 2))
            .addAction(snooze("Mañana", 24L * 60L * 60_000L, 3))
            .build()
        nm.notify(id, n)
    }
}
