package com.aztrallyx.calendario

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONObject

object Alarms {
    private fun prefs(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)

    private fun pi(c: Context, id: Int, t: String, b: String): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
            .putExtra("id", id).putExtra("t", t).putExtra("b", b)
        return PendingIntent.getBroadcast(
            c, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun set(c: Context, id: Int, t: String, b: String, at: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, id, t, b))
        prefs(c).edit().putString("a$id", JSONObject().put("t", t).put("b", b).put("at", at).toString()).apply()
    }

    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, id, "", ""))
        forget(c, id)
    }

    fun forget(c: Context, id: Int) {
        prefs(c).edit().remove("a$id").apply()
    }

    fun restore(c: Context) {
        val now = System.currentTimeMillis()
        for ((k, v) in prefs(c).all) {
            if (!k.startsWith("a") || v !is String) continue
            val o = JSONObject(v)
            val at = o.getLong("at")
            if (at > now) {
                val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val id = k.substring(1).toInt()
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, id, o.getString("t"), o.getString("b")))
            }
        }
    }
}
